import json
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

raw_data = [
  {
    "Scale_Factor": "1x",
    "Records_N": 50,
    "Workload_Type": "Empirical Baseline (50 real records)",
    "Single_Node_Time_Sec": 0.3199,
    "Single_Node_Min_Sec": 0.3024,
    "Single_Node_Max_Sec": 0.3642,
    "PySpark_Time_Sec": 5.605,
    "PySpark_Min_Sec": 4.9484,
    "PySpark_Max_Sec": 5.9277,
    "Spark_Cold_Start_Sec": 27.3466,
    "Relative_Speedup": 0.06,
    "Throughput_Rec_Per_Sec": 8.9,
    "Single_Node_Itemsets": 284,
    "PySpark_Itemsets": 284,
    "Regime": "Single-Node Faster (Spark Overhead Dominated)"
  },
  {
    "Scale_Factor": "10x",
    "Records_N": 500,
    "Workload_Type": "Synthetic Scaling Stress Test",
    "Single_Node_Time_Sec": 0.7946,
    "Single_Node_Min_Sec": 0.7839,
    "Single_Node_Max_Sec": 1.2743,
    "PySpark_Time_Sec": 2.8964,
    "PySpark_Min_Sec": 2.6041,
    "PySpark_Max_Sec": 3.2521,
    "Spark_Cold_Start_Sec": 0.0,
    "Relative_Speedup": 0.27,
    "Throughput_Rec_Per_Sec": 172.6,
    "Single_Node_Itemsets": 284,
    "PySpark_Itemsets": 284,
    "Regime": "Single-Node Faster (Spark Overhead Dominated)"
  },
  {
    "Scale_Factor": "100x",
    "Records_N": 5000,
    "Workload_Type": "Synthetic Scaling Stress Test",
    "Single_Node_Time_Sec": 8.5949,
    "Single_Node_Min_Sec": 8.3387,
    "Single_Node_Max_Sec": 8.9441,
    "PySpark_Time_Sec": 4.8568,
    "PySpark_Min_Sec": 4.0596,
    "PySpark_Max_Sec": 4.8585,
    "Spark_Cold_Start_Sec": 0.0,
    "Relative_Speedup": 1.77,
    "Throughput_Rec_Per_Sec": 1029.5,
    "Single_Node_Itemsets": 284,
    "PySpark_Itemsets": 284,
    "Regime": "Moderate Parallel Acceleration"
  },
  {
    "Scale_Factor": "1000x",
    "Records_N": 50000,
    "Workload_Type": "Synthetic Scaling Stress Test",
    "Single_Node_Time_Sec": 84.5109,
    "Single_Node_Min_Sec": 83.8367,
    "Single_Node_Max_Sec": 84.8575,
    "PySpark_Time_Sec": 14.9264,
    "PySpark_Min_Sec": 13.2902,
    "PySpark_Max_Sec": 15.7989,
    "Spark_Cold_Start_Sec": 0.0,
    "Relative_Speedup": 5.66,
    "Throughput_Rec_Per_Sec": 3349.8,
    "Single_Node_Itemsets": 284,
    "PySpark_Itemsets": 284,
    "Regime": "Strong Parallel Acceleration"
  }
]

df = pd.DataFrame(raw_data)
os.makedirs("outputs/rules", exist_ok=True)
os.makedirs("outputs/plots", exist_ok=True)

df.to_csv("outputs/rules/pyspark_benchmark_table.csv", index=False)
with open("outputs/rules/pyspark_benchmark_results.json", "w") as f:
    json.dump(raw_data, f, indent=2)

print("[OK] Saved CSV and JSON benchmark results to outputs/rules/")

# Generate high-resolution Plot 15
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

# Panel 1: Log-Log Runtime
ax1.plot(df['Records_N'], df['Single_Node_Time_Sec'], marker='o', markersize=9, linewidth=2.5, color='#e74c3c', label='Single-Node (sklearn / mlxtend)')
ax1.plot(df['Records_N'], df['PySpark_Time_Sec'], marker='s', markersize=9, linewidth=2.5, color='#2980b9', label='PySpark local[*] (Multi-Core)')
ax1.set_xscale('log')
ax1.set_yscale('log')
ax1.set_title('Absolute Execution Runtime vs. Dataset Scale\n(Log-Log Scale, Colab Certified Execution)', fontsize=13, fontweight='bold', pad=12)
ax1.set_xlabel('Dataset Size (Number of Records N)', fontsize=11, fontweight='bold')
ax1.set_ylabel('Execution Time (Seconds, Log Scale)', fontsize=11, fontweight='bold')
ax1.grid(True, which='both', ls='--', alpha=0.5)
ax1.legend(frameon=True, facecolor='white', framealpha=0.9, fontsize=10)

for _, r in df.iterrows():
    ax1.annotate(f"{r['Single_Node_Time_Sec']:.2f}s", (r['Records_N'], r['Single_Node_Time_Sec']), textcoords='offset points', xytext=(0, 10), ha='center', fontsize=9, color='#c0392b', weight='bold')
    ax1.annotate(f"{r['PySpark_Time_Sec']:.2f}s", (r['Records_N'], r['PySpark_Time_Sec']), textcoords='offset points', xytext=(0, -16), ha='center', fontsize=9, color='#2471a3', weight='bold')

# Panel 2: Speedup Factor
colors = ['#e74c3c' if s < 1.0 else '#27ae60' for s in df['Relative_Speedup']]
bars = ax2.bar(df['Scale_Factor'], df['Relative_Speedup'], color=colors, edgecolor='black', linewidth=1.2, width=0.48)
ax2.axhline(1.0, color='#2c3e50', linestyle='--', linewidth=2.0, label='Parity Threshold (Speedup = 1.0x)')
ax2.set_title('PySpark Relative Speedup Factor ($S = T_{single} / T_{spark}$)', fontsize=13, fontweight='bold', pad=12)
ax2.set_xlabel('Geometric Replication Factor', fontsize=11, fontweight='bold')
ax2.set_ylabel('Speedup Ratio (x)', fontsize=11, fontweight='bold')
ax2.grid(True, linestyle=':', alpha=0.6, axis='y')

for bar in bars:
    height = bar.get_height()
    ax2.annotate(f'{height:.2f}x', xy=(bar.get_x() + bar.get_width() / 2, height), xytext=(0, 5), textcoords='offset points', ha='center', va='bottom', fontsize=10.5, fontweight='bold')
ax2.legend(frameon=True, facecolor='white', framealpha=0.9, fontsize=10)

crossover_text = (
    'Certified Colab Benchmark Dynamics:\n'
    '• 1x - 10x: Overhead Regime (S < 1.0x)\n'
    '  Cold startup (27.35s) & JVM coordination.\n'
    '  Single-Node faster on small batches.\n'
    '• Crossover Interval: [500, 5,000] records.\n'
    '• 100x: 1.77x speedup (4.86s vs 8.59s).\n'
    '• 1000x: 5.66x strong speedup (14.93s vs 84.51s).'
)
ax2.text(0.04, 0.95, crossover_text, transform=ax2.transAxes, fontsize=9.5, verticalalignment='top', bbox=dict(boxstyle='round,pad=0.6', facecolor='#f8f9fa', edgecolor='#bdc3c7', alpha=0.95))

plt.suptitle('Figure 15: PySpark Distributed Scaling Benchmark vs. Single-Node Engine', fontsize=14, fontweight='bold', y=1.03)
plt.tight_layout()
out_plot = 'outputs/plots/plot15_pyspark_speedup.png'
plt.savefig(out_plot, dpi=300, bbox_inches='tight')
print(f'[OK] Generated {out_plot} ({os.path.getsize(out_plot):,} bytes)')
